
CREATE DATABASE IF NOT EXISTS devlink;
USE devlink;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Sample user: username: admin, password: admin123 (hashed)
INSERT INTO users (username, password) VALUES
('admin', '$2y$10$5f2qKVo6c3QK1H5wRn4MqOy3WwSxPKq9PX6LtwN0CvGW9SKGq3qx2');
