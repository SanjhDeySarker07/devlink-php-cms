<?php include 'includes/header.php'; ?>
<h1>Welcome to My Portfolio</h1>
<?php include 'includes/footer.php'; ?>